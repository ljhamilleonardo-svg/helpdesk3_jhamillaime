/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.helpdesk3_jhamillaime;

/**
 *
 * @author JHAMIL
 */
public class Helpdesk3_jhamillaime {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
