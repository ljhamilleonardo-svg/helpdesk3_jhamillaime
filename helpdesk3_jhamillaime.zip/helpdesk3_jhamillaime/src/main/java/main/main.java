
package main;
import vista.InterfazLogin;
public class main {
    public static void main(String[] args) {
        InterfazLogin interfaz = new InterfazLogin();
        interfaz.setVisible(true);
    }
}
