package controlador;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Cliente mínimo para Responses API. La clave se lee únicamente del entorno. */
public class AsistenteIA {
    private static final Pattern TEXTO = Pattern.compile("\\\"type\\\"\\s*:\\s*\\\"output_text\\\"[^}]*?\\\"text\\\"\\s*:\\s*\\\"((?:\\\\\\\\.|[^\\\"\\\\\\\\])*)\\\"", Pattern.DOTALL);
    private final HttpClient cliente = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(20)).build();

    public String responder(String pregunta) throws Exception {
        String clave=System.getenv("OPENAI_API_KEY");
        if(clave==null||clave.isBlank()) throw new IllegalStateException("Configura la variable OPENAI_API_KEY para activar el asistente IA.");
        String modelo=System.getenv().getOrDefault("OPENAI_MODEL","gpt-4o-mini");
        String entrada="Eres el asistente de un sistema de mesa de ayuda. Responde en español, con pasos concretos y breves. "
                + "Ayuda a clasificar y resolver incidencias de soporte. No afirmes que registraste o modificaste datos.\n\nConsulta: " + pregunta;
        String body="{\"model\":"+json(modelo)+",\"input\":"+json(entrada)+",\"max_output_tokens\":500}";
        HttpRequest request=HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/responses"))
                .timeout(Duration.ofSeconds(60)).header("Authorization","Bearer "+clave)
                .header("Content-Type","application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body,StandardCharsets.UTF_8)).build();
        HttpResponse<String> response=cliente.send(request,HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if(response.statusCode()<200||response.statusCode()>=300) {
            String detalle=response.body(); if(detalle.length()>500)detalle=detalle.substring(0,500);
            throw new IllegalStateException("La API respondió HTTP "+response.statusCode()+": "+detalle);
        }
        Matcher matcher=TEXTO.matcher(response.body());
        if(!matcher.find()) throw new IllegalStateException("La API respondió, pero no se encontró texto de salida.");
        return unjson(matcher.group(1));
    }
    private static String json(String s){
        StringBuilder b=new StringBuilder("\"");
        for(char c:s.toCharArray()) switch(c){case '\\'->b.append("\\\\");case '"'->b.append("\\\"");case '\n'->b.append("\\n");case '\r'->b.append("\\r");case '\t'->b.append("\\t");default->{if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}}
        return b.append('"').toString();
    }
    private static String unjson(String s){
        StringBuilder b=new StringBuilder();
        for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c!='\\'||i+1>=s.length()){b.append(c);continue;}char n=s.charAt(++i);switch(n){case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');case '"'->b.append('"');case '\\'->b.append('\\');case '/'->b.append('/');case 'u'->{if(i+4<s.length()){b.append((char)Integer.parseInt(s.substring(i+1,i+5),16));i+=4;}}default->b.append(n);}}
        return b.toString();
    }
}