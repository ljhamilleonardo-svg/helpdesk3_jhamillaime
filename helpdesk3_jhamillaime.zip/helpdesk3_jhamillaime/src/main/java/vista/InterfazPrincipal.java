package vista;

import controlador.LoginController;
import controlador.TecnicoController;

public class InterfazPrincipal extends javax.swing.JFrame {  
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(InterfazPrincipal.class.getName());
    private TecnicoController tecnicoController = new TecnicoController();
    private final modelo.IncidenciaDao incidenciaDao = new modelo.IncidenciaDao();
    private final modelo.EspecialidadDao especialidadDao = new modelo.EspecialidadDao();
    private final modelo.UsuarioDao usuarioDaoReal = new modelo.UsuarioDao();
    private final controlador.AsistenteIA asistenteIA = new controlador.AsistenteIA();
    private final javax.swing.JTextArea chatAsistente = new javax.swing.JTextArea();
    private final javax.swing.JTextField entradaAsistente = new javax.swing.JTextField();
    private final javax.swing.JButton botonAsistente = new javax.swing.JButton("Enviar");
    private final javax.swing.JTextField campoUsuId = new javax.swing.JTextField();
    private final javax.swing.JTextField campoUsuNombre = new javax.swing.JTextField();
    private final javax.swing.JTextField campoUsuApellido = new javax.swing.JTextField();
    private final javax.swing.JTextField campoUsuCorreo = new javax.swing.JTextField();
    private final javax.swing.JTextField campoUsuTelefono = new javax.swing.JTextField();
    private final javax.swing.JTextField campoUsuLogin = new javax.swing.JTextField();
    private final javax.swing.JPasswordField campoUsuPassword = new javax.swing.JPasswordField();
    private final javax.swing.JComboBox<String> comboUsuEstado = new javax.swing.JComboBox<>(new String[]{"Activo", "Inactivo"});
    private final javax.swing.JTextField campoUsuBuscar = new javax.swing.JTextField();
    private final javax.swing.JTable tablaUsuariosReal = new javax.swing.JTable();
    public InterfazPrincipal() {
        initComponents();
        jTabbedPane3.setComponentAt(1, crearPanelUsuarios());
        jTabbedPane3.setComponentAt(6, crearPanelAsistente());
        cargarTablaUsuariosReal();
        setResizable(false);
        setTitle("Panel de administracion");
        setLocationRelativeTo(null);
        LoginController login=new LoginController(this);
        cargarComboTecnico();
        cargarComboCategorias();
        cargarTablaCategorias();
        cargarTablaTecnicos();

        cargarTablaEspecialidades();
        btnEspecRegis.addActionListener(e -> guardarEspecialidad(null));
        btnEspecMod.addActionListener(e -> guardarEspecialidad(idEspecialidadSeleccionada()));
        btnEspecElimi.addActionListener(e -> eliminarEspecialidad());
        btnEspecLimp.addActionListener(e -> limpiarEspecialidad());
        tableEspecialidades.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) cargarEspecialidadSeleccionada();
        });
        txtEspecBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void actualizar() { tableEspecialidades.setModel(especialidadDao.listar(txtEspecBuscar.getText().trim())); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
        });
        btnCateRegis.addActionListener(e -> guardarCategoria(null));
        btnCatecModif.addActionListener(e -> guardarCategoria(idCategoriaSeleccionada()));
        btnCatecElimi.addActionListener(e -> eliminarCategoria());
        btnCatecLimp.addActionListener(e -> limpiarCategoria());
        tableCategorias.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) cargarCategoriaSeleccionada();
        });
        txtCateBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void actualizar() { tableCategorias.setModel(new modelo.CategoriaDao().buscar(txtCateBuscar.getText().trim())); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { actualizar(); }
        });
        btnReportGene.addActionListener(e -> generarReporte());   // NUEVA
        btnReporLimp.addActionListener(e -> limpiarReporte());
        
        this.repaint();
    }

    private javax.swing.JPanel crearPanelAsistente(){
        javax.swing.JPanel panel=new javax.swing.JPanel(new java.awt.BorderLayout(8,8));
        chatAsistente.setEditable(false);chatAsistente.setLineWrap(true);chatAsistente.setWrapStyleWord(true);
        panel.add(new javax.swing.JScrollPane(chatAsistente),java.awt.BorderLayout.CENTER);
        javax.swing.JPanel enviar=new javax.swing.JPanel(new java.awt.BorderLayout(6,6));
        enviar.add(entradaAsistente,java.awt.BorderLayout.CENTER);enviar.add(botonAsistente,java.awt.BorderLayout.EAST);
        panel.add(enviar,java.awt.BorderLayout.SOUTH);
        botonAsistente.addActionListener(e -> enviarAlAsistente());
        entradaAsistente.addActionListener(e -> enviarAlAsistente());
        chatAsistente.setText("Asistente de soporte IA. Escribe tu consulta. Requiere OPENAI_API_KEY en el entorno.");
        return panel;
    }
    private void enviarAlAsistente(){
        String pregunta=entradaAsistente.getText().trim();if(pregunta.isEmpty())return;
        entradaAsistente.setText("");botonAsistente.setEnabled(false);
        chatAsistente.append("\n\nTú: "+pregunta+"\nAsistente: pensando...");
        new javax.swing.SwingWorker<String,Void>(){
            protected String doInBackground() throws Exception{return asistenteIA.responder(pregunta);}
            protected void done(){
                try{String texto=get();int inicio=chatAsistente.getText().lastIndexOf("Asistente: pensando...");if(inicio>=0)chatAsistente.replaceRange("Asistente: "+texto,inicio,chatAsistente.getText().length());}
                catch(Exception ex){int inicio=chatAsistente.getText().lastIndexOf("Asistente: pensando...");String error=ex.getCause()==null?ex.getMessage():ex.getCause().getMessage();if(inicio>=0)chatAsistente.replaceRange("Asistente: "+error,inicio,chatAsistente.getText().length());}
                botonAsistente.setEnabled(true);
            }
        }.execute();
    }
    private javax.swing.JPanel crearPanelUsuarios() {
        javax.swing.JPanel panel=new javax.swing.JPanel(new java.awt.BorderLayout(8,8));
        javax.swing.JPanel formulario=new javax.swing.JPanel(new java.awt.GridLayout(0,4,6,6));
        campoUsuId.setEditable(false);
        formulario.add(new javax.swing.JLabel("ID")); formulario.add(campoUsuId);
        formulario.add(new javax.swing.JLabel("Estado")); formulario.add(comboUsuEstado);
        formulario.add(new javax.swing.JLabel("Nombre")); formulario.add(campoUsuNombre);
        formulario.add(new javax.swing.JLabel("Apellido")); formulario.add(campoUsuApellido);
        formulario.add(new javax.swing.JLabel("Correo")); formulario.add(campoUsuCorreo);
        formulario.add(new javax.swing.JLabel("Teléfono")); formulario.add(campoUsuTelefono);
        formulario.add(new javax.swing.JLabel("Usuario")); formulario.add(campoUsuLogin);
        formulario.add(new javax.swing.JLabel("Contraseña")); formulario.add(campoUsuPassword);
        javax.swing.JButton registrar=new javax.swing.JButton("Registrar");
        javax.swing.JButton modificar=new javax.swing.JButton("Modificar");
        javax.swing.JButton eliminar=new javax.swing.JButton("Eliminar");
        javax.swing.JButton limpiar=new javax.swing.JButton("Limpiar");
        javax.swing.JPanel acciones=new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        acciones.add(registrar);acciones.add(modificar);acciones.add(eliminar);acciones.add(limpiar);
        javax.swing.JPanel superior=new javax.swing.JPanel(new java.awt.BorderLayout(4,4));
        superior.add(formulario,java.awt.BorderLayout.CENTER);superior.add(acciones,java.awt.BorderLayout.SOUTH);
        javax.swing.JPanel busqueda=new javax.swing.JPanel(new java.awt.BorderLayout(5,5));
        busqueda.add(new javax.swing.JLabel("Buscar usuario:"),java.awt.BorderLayout.WEST);busqueda.add(campoUsuBuscar,java.awt.BorderLayout.CENTER);
        javax.swing.JPanel encabezado=new javax.swing.JPanel(new java.awt.BorderLayout(4,4));encabezado.add(superior,java.awt.BorderLayout.NORTH);encabezado.add(busqueda,java.awt.BorderLayout.SOUTH);
        panel.add(encabezado,java.awt.BorderLayout.NORTH);panel.add(new javax.swing.JScrollPane(tablaUsuariosReal),java.awt.BorderLayout.CENTER);
        registrar.addActionListener(e -> guardarUsuarioReal(false));
        modificar.addActionListener(e -> guardarUsuarioReal(true));
        eliminar.addActionListener(e -> eliminarUsuarioReal());
        limpiar.addActionListener(e -> limpiarUsuarioReal());
        tablaUsuariosReal.getSelectionModel().addListSelectionListener(e -> {if(!e.getValueIsAdjusting())cargarUsuarioReal();});
        campoUsuBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){
            private void actualizar(){tablaUsuariosReal.setModel(usuarioDaoReal.buscar(campoUsuBuscar.getText().trim()));}
            public void insertUpdate(javax.swing.event.DocumentEvent e){actualizar();}
            public void removeUpdate(javax.swing.event.DocumentEvent e){actualizar();}
            public void changedUpdate(javax.swing.event.DocumentEvent e){actualizar();}
        });
        return panel;
    }
    private void cargarTablaUsuariosReal(){tablaUsuariosReal.setModel(usuarioDaoReal.listar());}
    private void cargarUsuarioReal(){
        int f=tablaUsuariosReal.getSelectedRow();if(f<0)return;
        campoUsuId.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,0)));
        campoUsuNombre.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,1)));
        campoUsuApellido.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,2)));
        campoUsuCorreo.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,3)));
        campoUsuTelefono.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,4)));
        campoUsuLogin.setText(String.valueOf(tablaUsuariosReal.getValueAt(f,5)));
        comboUsuEstado.setSelectedItem(String.valueOf(tablaUsuariosReal.getValueAt(f,6)));
        campoUsuPassword.setText("");
    }
    private void guardarUsuarioReal(boolean modificar){
        String nombre=campoUsuNombre.getText().trim(), apellido=campoUsuApellido.getText().trim();
        String correo=campoUsuCorreo.getText().trim(), telefono=campoUsuTelefono.getText().trim(), login=campoUsuLogin.getText().trim();
        String password=new String(campoUsuPassword.getPassword());
        if(nombre.isEmpty()||apellido.isEmpty()||login.isEmpty()||(!modificar&&password.isEmpty())){
            javax.swing.JOptionPane.showMessageDialog(this,"Nombre, apellido y usuario son obligatorios. Para crear una cuenta, ingresa también la contraseña.");return;
        }
        try{
            boolean ok;
            if(modificar){int id=Integer.parseInt(campoUsuId.getText().trim());ok=usuarioDaoReal.modificar(new modelo.Usuario(id,nombre,apellido,correo,telefono,login,password,(String)comboUsuEstado.getSelectedItem()));}
            else ok=usuarioDaoReal.registrar(new modelo.Usuario(nombre,apellido,correo,telefono,login,password,(String)comboUsuEstado.getSelectedItem()));
            if(ok){cargarTablaUsuariosReal();limpiarUsuarioReal();}
        }catch(NumberFormatException ex){javax.swing.JOptionPane.showMessageDialog(this,"Selecciona una cuenta de la tabla para modificar.");}
    }
    private void eliminarUsuarioReal(){
        try{int id=Integer.parseInt(campoUsuId.getText().trim());
            if(javax.swing.JOptionPane.showConfirmDialog(this,"¿Eliminar esta cuenta?","Confirmar",javax.swing.JOptionPane.YES_NO_OPTION)==javax.swing.JOptionPane.YES_OPTION&&usuarioDaoReal.eliminar(id)){cargarTablaUsuariosReal();limpiarUsuarioReal();}
        }catch(NumberFormatException ex){javax.swing.JOptionPane.showMessageDialog(this,"Selecciona una cuenta para eliminar.");}
    }
    private void limpiarUsuarioReal(){campoUsuId.setText("");campoUsuNombre.setText("");campoUsuApellido.setText("");campoUsuCorreo.setText("");campoUsuTelefono.setText("");campoUsuLogin.setText("");campoUsuPassword.setText("");comboUsuEstado.setSelectedIndex(0);tablaUsuariosReal.clearSelection();}
    private void generarReporte() {
        reportes.ReporteIncidencias reporte = new reportes.ReporteIncidencias();
        String desde = txtReporFecha.getText().trim();
        String hasta = txtReporFechaH.getText().trim();
        String categoria = txtReportCate.getText().trim();
        String prioridad = txtReportPrio.getText().trim();
        String estado = txtReporEsta.getText().trim();
        String tecnico = txtReportTec.getText().trim();
        tableReportes.setModel(reporte.consultar(desde, hasta, categoria, prioridad, estado, tecnico));
        reporte.generarPdf(desde, hasta, categoria, prioridad, estado, tecnico);
    }

    private void limpiarReporte() {
        txtReporFecha.setText("");
        txtReporFechaH.setText("");
        txtReportCate.setText("");
        txtReportPrio.setText("");
        txtReporEsta.setText("");
        txtReportTec.setText("");
        tableReportes.setModel(new javax.swing.table.DefaultTableModel(
                new Object[]{"Id", "Titulo", "Categoria", "Prioridad", "Estado", "Tecnico"}, 0));
    }
    // Carga inicial de los combos del formulario de Tecnicos.
    // TODO: si ya tienes la tabla "especialidad" en tu BD, reemplaza este llenado
    // fijo por una consulta (por ejemplo con un metodo listar() en un EspecialidadDao).
    private void cargarComboTecnico() {
        comboxTecEstado.removeAllItems();
        comboxTecEstado.addItem("Activo");
        comboxTecEstado.addItem("Inactivo");

        comboxTecEspec.removeAllItems();
        comboxTecEspec.addItem("Hardware");
        comboxTecEspec.addItem("Software");
        comboxTecEspec.addItem("Redes");
        comboxEspecEstado.removeAllItems();
        comboxEspecEstado.addItem("Activo");
        comboxEspecEstado.addItem("Inactivo");
        comboxEspecNivel.removeAllItems();
        comboxEspecNivel.addItem("Inicial");
        comboxEspecNivel.addItem("Intermedio");
        comboxEspecNivel.addItem("Avanzado");
    }

    private void cargarComboCategorias() {
        comboxInciCate.removeAllItems();
        comboxInciCate.addItem("Selecciona categoría");
        comboxUsuCat2.removeAllItems();
        comboxUsuCat2.addItem("Selecciona categoría");
        if (comboxCateEstado.getItemCount() == 0) {
            comboxCateEstado.addItem("Activo");
            comboxCateEstado.addItem("Inactivo");
        }
                new modelo.CategoriaDao().listarActivas().forEach((id, nombre) -> {
            comboxInciCate.addItem(nombre);
            comboxUsuCat2.addItem(nombre);
        });
    }

    private modelo.CategoriaDao categoriaDao = new modelo.CategoriaDao();

    private void cargarTablaCategorias() { tableCategorias.setModel(categoriaDao.listar()); }

    private Integer idCategoriaSeleccionada() {
        try { return Integer.valueOf(txtCateID.getText().trim()); }
        catch (NumberFormatException ex) { return null; }
    }

    private void cargarCategoriaSeleccionada() {
        int fila = tableCategorias.getSelectedRow();
        if (fila < 0) return;
        txtCateID.setText(String.valueOf(tableCategorias.getValueAt(fila, 0)));
        txtCateNom.setText(String.valueOf(tableCategorias.getValueAt(fila, 1)));
        txtCateDescrip.setText(String.valueOf(tableCategorias.getValueAt(fila, 2)));
        comboxCateEstado.setSelectedItem(tableCategorias.getValueAt(fila, 3));
    }

    private void guardarCategoria(Integer id) {
        String nombre = txtCateNom.getText().trim();
        if (nombre.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Escribe el nombre de la categoría.");
            return;
        }
        if (categoriaDao.guardar(id, nombre, txtCateDescrip.getText().trim(),
                String.valueOf(comboxCateEstado.getSelectedItem()))) {
            cargarTablaCategorias(); cargarComboCategorias(); limpiarCategoria();
        }
    }

    private void eliminarCategoria() {
        Integer id = idCategoriaSeleccionada();
        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Selecciona una categoría de la tabla.");
            return;
        }
        if (javax.swing.JOptionPane.showConfirmDialog(this, "¿Eliminar la categoría seleccionada?",
                "Confirmar", javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION
                && categoriaDao.eliminar(id)) {
            cargarTablaCategorias(); cargarComboCategorias(); limpiarCategoria();
        }
    }

    private void limpiarCategoria() {
        txtCateID.setText(""); txtCateNom.setText(""); txtCateDescrip.setText("");
        tableCategorias.clearSelection();
        if (comboxCateEstado.getItemCount() > 0) comboxCateEstado.setSelectedIndex(0);
    }

    private void cargarTablaIncidencias() { TableIncidencia.setModel(incidenciaDao.listar()); }

    private Integer idIncidenciaSeleccionada() {
        try { return Integer.valueOf(txtInciId.getText().trim()); }
        catch (NumberFormatException ex) { return null; }
    }

    private void cargarIncidenciaSeleccionada() {
        int fila = TableIncidencia.getSelectedRow();
        if (fila < 0) return;
        txtInciId.setText(String.valueOf(TableIncidencia.getValueAt(fila, 0)));
        txtInciTit.setText(String.valueOf(TableIncidencia.getValueAt(fila, 2)));
        comboxInciCate.setSelectedItem(TableIncidencia.getValueAt(fila, 3));
        txtInciPrio.setText(String.valueOf(TableIncidencia.getValueAt(fila, 4)));
        txtInciEst.setText(String.valueOf(TableIncidencia.getValueAt(fila, 5)));
        txtInciUsu.setText(String.valueOf(TableIncidencia.getValueAt(fila, 6)));
        txtInciTec.setText(String.valueOf(TableIncidencia.getValueAt(fila, 7)));
    }

    private void guardarIncidencia(Integer id) {
        try {
            String categoria = (String) comboxInciCate.getSelectedItem();
            if (categoria == null || categoria.startsWith("Selecciona")) throw new IllegalArgumentException("Selecciona una categoría activa.");
            String estado = txtInciEst.getText().trim();
            if (estado.isEmpty()) estado = "Abierta";
            Integer tecnico = txtInciTec.getText().trim().isEmpty() ? null : Integer.valueOf(txtInciTec.getText().trim());
            int usuario = Integer.parseInt(txtInciUsu.getText().trim());
            if (txtInciTit.getText().trim().isEmpty()) throw new IllegalArgumentException("El título es obligatorio.");
            if (incidenciaDao.guardar(id, txtInciTit.getText().trim(), txtInciDes.getText().trim(), categoria,
                    txtInciPrio.getText().trim().isEmpty() ? "Media" : txtInciPrio.getText().trim(), estado, usuario, tecnico)) {
                cargarTablaIncidencias(); limpiarIncidencia();
            }
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Usuario y técnico deben ser IDs numéricos; el técnico puede quedar vacío.");
        } catch (IllegalArgumentException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void eliminarIncidencia() {
        Integer id = idIncidenciaSeleccionada();
        if (id == null) { javax.swing.JOptionPane.showMessageDialog(this, "Selecciona una incidencia."); return; }
        if (javax.swing.JOptionPane.showConfirmDialog(this, "¿Eliminar esta incidencia?", "Confirmar", javax.swing.JOptionPane.YES_NO_OPTION)
                == javax.swing.JOptionPane.YES_OPTION && incidenciaDao.eliminar(id)) {
            cargarTablaIncidencias(); limpiarIncidencia();
        }
    }

    private void limpiarIncidencia() {
        txtInciId.setText(""); txtInciTit.setText(""); txtInciDes.setText("");
        txtInciPrio.setText(""); txtInciEst.setText(""); txtInciUsu.setText(""); txtInciTec.setText("");
        TableIncidencia.clearSelection();
    }
    private void cargarTablaEspecialidades() { tableEspecialidades.setModel(especialidadDao.listar("")); }
    private Integer idEspecialidadSeleccionada() { try { return Integer.valueOf(txtEspecID.getText().trim()); } catch (NumberFormatException ex) { return null; } }
    private void cargarEspecialidadSeleccionada() {
        int f=tableEspecialidades.getSelectedRow(); if(f<0)return;
        txtEspecID.setText(String.valueOf(tableEspecialidades.getValueAt(f,0)));
        txtEspecNom.setText(String.valueOf(tableEspecialidades.getValueAt(f,1)));
        txtEspecDescrip.setText(String.valueOf(tableEspecialidades.getValueAt(f,2)));
        comboxEspecEstado.setSelectedItem(tableEspecialidades.getValueAt(f,3));
        comboxEspecNivel.setSelectedItem(tableEspecialidades.getValueAt(f,4));
    }
    private void guardarEspecialidad(Integer id) {
        String nombre=txtEspecNom.getText().trim();
        if(nombre.isEmpty()){javax.swing.JOptionPane.showMessageDialog(this,"Escribe el nombre de la especialidad.");return;}
        if(especialidadDao.guardar(id,nombre,txtEspecDescrip.getText().trim(),String.valueOf(comboxEspecEstado.getSelectedItem()),String.valueOf(comboxEspecNivel.getSelectedItem()))){cargarTablaEspecialidades();limpiarEspecialidad();}
    }
    private void eliminarEspecialidad() {
        Integer id=idEspecialidadSeleccionada(); if(id==null){javax.swing.JOptionPane.showMessageDialog(this,"Selecciona una especialidad.");return;}
        if(javax.swing.JOptionPane.showConfirmDialog(this,"¿Eliminar la especialidad seleccionada?","Confirmar",javax.swing.JOptionPane.YES_NO_OPTION)==javax.swing.JOptionPane.YES_OPTION && especialidadDao.eliminar(id)){cargarTablaEspecialidades();limpiarEspecialidad();}
    }
    private void limpiarEspecialidad() {
        txtEspecID.setText("");txtEspecNom.setText("");txtEspecDescrip.setText("");tableEspecialidades.clearSelection();
        if(comboxEspecEstado.getItemCount()>0)comboxEspecEstado.setSelectedIndex(0);
        if(comboxEspecNivel.getItemCount()>0)comboxEspecNivel.setSelectedIndex(0);
    }
    private void cargarTablaTecnicos() {
        tecnicoController.listarTecnicos(TableUsuario1);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Menu = new javax.swing.JPanel();
        panelincidencia = new javax.swing.JPanel();
        lblincidencias = new javax.swing.JLabel();
        panelUsuarios = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        panelTecnicos = new javax.swing.JPanel();
        lblTecnicos = new javax.swing.JLabel();
        panelCategorias = new javax.swing.JPanel();
        lblCategorias = new javax.swing.JLabel();
        panelEspecialidades = new javax.swing.JPanel();
        lblEspecialidades = new javax.swing.JLabel();
        panelReportes = new javax.swing.JPanel();
        lblReportes = new javax.swing.JLabel();
        panelAsistente = new javax.swing.JPanel();
        lblAsistente = new javax.swing.JLabel();
        panelLogo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Cabecera = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        btnsalir = new javax.swing.JButton();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtInciTit = new javax.swing.JTextField();
        txtInciDes = new javax.swing.JTextField();
        txtInciPrio = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtInciEst = new javax.swing.JTextField();
        txtInciUsu = new javax.swing.JTextField();
        txtInciTec = new javax.swing.JTextField();
        txtInciId = new javax.swing.JTextField();
        btnInciReg = new javax.swing.JButton();
        btnInciMod = new javax.swing.JButton();
        btnInciElim = new javax.swing.JButton();
        btnInciLim = new javax.swing.JButton();
        comboxInciCate = new javax.swing.JComboBox<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        TableIncidencia = new javax.swing.JTable();
        jPanel23 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtUsuCod2 = new javax.swing.JTextField();
        txtUsuNom2 = new javax.swing.JTextField();
        txtUsuPre2 = new javax.swing.JTextField();
        txtUsuDes2 = new javax.swing.JTextField();
        txtUsuId2 = new javax.swing.JTextField();
        comboxUsuCat2 = new javax.swing.JComboBox<>();
        btnUsuReg2 = new javax.swing.JButton();
        btnUsuMod2 = new javax.swing.JButton();
        btnUsuElim2 = new javax.swing.JButton();
        btnUsuCanc2 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        TableUsuario = new javax.swing.JTable();
        jPanel20 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        btnTecRegistrar = new javax.swing.JButton();
        btnTecModif = new javax.swing.JButton();
        btnTecElimi = new javax.swing.JButton();
        btnTecLim = new javax.swing.JButton();
        txtTecNom = new javax.swing.JTextField();
        txxTecApell = new javax.swing.JTextField();
        txtTecCI = new javax.swing.JTextField();
        txtTecTelef = new javax.swing.JTextField();
        txtTecCorreo = new javax.swing.JTextField();
        txtTecID = new javax.swing.JTextField();
        comboxTecEstado = new javax.swing.JComboBox<>();
        comboxTecEspec = new javax.swing.JComboBox<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        TableUsuario1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btnCateRegis = new javax.swing.JButton();
        btnCatecModif = new javax.swing.JButton();
        btnCatecLimp = new javax.swing.JButton();
        btnCatecElimi = new javax.swing.JButton();
        txtCateID = new javax.swing.JTextField();
        txtCateNom = new javax.swing.JTextField();
        comboxCateEstado = new javax.swing.JComboBox<>();
        txtCateDescrip = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        txtCateBuscar = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        tableCategorias = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        btnEspecRegis = new javax.swing.JButton();
        btnEspecMod = new javax.swing.JButton();
        btnEspecLimp = new javax.swing.JButton();
        btnEspecElimi = new javax.swing.JButton();
        txtEspecID = new javax.swing.JTextField();
        txtEspecNom = new javax.swing.JTextField();
        comboxEspecEstado = new javax.swing.JComboBox<>();
        txtEspecDescrip = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        comboxEspecNivel = new javax.swing.JComboBox<>();
        jLabel41 = new javax.swing.JLabel();
        txtEspecBuscar = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        tableEspecialidades = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        txtReporFecha = new javax.swing.JTextField();
        txtReporFechaH = new javax.swing.JTextField();
        txtReportCate = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        txtReportPrio = new javax.swing.JTextField();
        txtReporEsta = new javax.swing.JTextField();
        txtReportTec = new javax.swing.JTextField();
        btnReportGene = new javax.swing.JButton();
        btnReporLimp = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        tableReportes = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Menu.setBackground(new java.awt.Color(0, 204, 204));
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelincidencia.setBackground(new java.awt.Color(0, 0, 102));
        panelincidencia.setForeground(new java.awt.Color(255, 255, 255));

        lblincidencias.setBackground(new java.awt.Color(51, 255, 51));
        lblincidencias.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblincidencias.setForeground(new java.awt.Color(255, 255, 255));
        lblincidencias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/incidencia.png"))); // NOI18N
        lblincidencias.setText("Incidencias");

        javax.swing.GroupLayout panelincidenciaLayout = new javax.swing.GroupLayout(panelincidencia);
        panelincidencia.setLayout(panelincidenciaLayout);
        panelincidenciaLayout.setHorizontalGroup(
            panelincidenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblincidencias, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
        );
        panelincidenciaLayout.setVerticalGroup(
            panelincidenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelincidenciaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblincidencias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Menu.add(panelincidencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 200, 50));

        panelUsuarios.setBackground(new java.awt.Color(0, 0, 102));
        panelUsuarios.setForeground(new java.awt.Color(255, 255, 255));

        lblUsuario.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/usuarios.png"))); // NOI18N
        lblUsuario.setText("Usuarios");

        javax.swing.GroupLayout panelUsuariosLayout = new javax.swing.GroupLayout(panelUsuarios);
        panelUsuarios.setLayout(panelUsuariosLayout);
        panelUsuariosLayout.setHorizontalGroup(
            panelUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUsuariosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE)
                .addGap(27, 27, 27))
        );
        panelUsuariosLayout.setVerticalGroup(
            panelUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUsuariosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Menu.add(panelUsuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 200, -1));

        panelTecnicos.setBackground(new java.awt.Color(0, 0, 102));
        panelTecnicos.setForeground(new java.awt.Color(255, 255, 255));

        lblTecnicos.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblTecnicos.setForeground(new java.awt.Color(255, 255, 255));
        lblTecnicos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/tecnico.png"))); // NOI18N
        lblTecnicos.setText("Tecnicos");

        javax.swing.GroupLayout panelTecnicosLayout = new javax.swing.GroupLayout(panelTecnicos);
        panelTecnicos.setLayout(panelTecnicosLayout);
        panelTecnicosLayout.setHorizontalGroup(
            panelTecnicosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTecnicosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTecnicos, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );
        panelTecnicosLayout.setVerticalGroup(
            panelTecnicosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTecnicosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTecnicos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Menu.add(panelTecnicos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 200, 50));

        panelCategorias.setBackground(new java.awt.Color(0, 0, 102));
        panelCategorias.setForeground(new java.awt.Color(255, 255, 255));

        lblCategorias.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblCategorias.setForeground(new java.awt.Color(255, 255, 255));
        lblCategorias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/categoria_1x1cm.png"))); // NOI18N
        lblCategorias.setText("Categorias");

        javax.swing.GroupLayout panelCategoriasLayout = new javax.swing.GroupLayout(panelCategorias);
        panelCategorias.setLayout(panelCategoriasLayout);
        panelCategoriasLayout.setHorizontalGroup(
            panelCategoriasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCategoriasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCategorias, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                .addGap(18, 18, 18))
        );
        panelCategoriasLayout.setVerticalGroup(
            panelCategoriasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCategoriasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCategorias, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE))
        );

        Menu.add(panelCategorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 200, 50));

        panelEspecialidades.setBackground(new java.awt.Color(0, 0, 102));
        panelEspecialidades.setForeground(new java.awt.Color(255, 255, 255));

        lblEspecialidades.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblEspecialidades.setForeground(new java.awt.Color(255, 255, 255));
        lblEspecialidades.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/especialidades.png"))); // NOI18N
        lblEspecialidades.setText("Especialidades");

        javax.swing.GroupLayout panelEspecialidadesLayout = new javax.swing.GroupLayout(panelEspecialidades);
        panelEspecialidades.setLayout(panelEspecialidadesLayout);
        panelEspecialidadesLayout.setHorizontalGroup(
            panelEspecialidadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelEspecialidadesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblEspecialidades, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        panelEspecialidadesLayout.setVerticalGroup(
            panelEspecialidadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelEspecialidadesLayout.createSequentialGroup()
                .addComponent(lblEspecialidades)
                .addGap(0, 9, Short.MAX_VALUE))
        );

        Menu.add(panelEspecialidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 200, 50));

        panelReportes.setBackground(new java.awt.Color(0, 0, 102));
        panelReportes.setForeground(new java.awt.Color(255, 255, 255));

        lblReportes.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblReportes.setForeground(new java.awt.Color(255, 255, 255));
        lblReportes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/reporte.png"))); // NOI18N
        lblReportes.setText("Reportes");
        lblReportes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReportesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelReportesLayout = new javax.swing.GroupLayout(panelReportes);
        panelReportes.setLayout(panelReportesLayout);
        panelReportesLayout.setHorizontalGroup(
            panelReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelReportesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        panelReportesLayout.setVerticalGroup(
            panelReportesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelReportesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblReportes)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Menu.add(panelReportes, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 200, -1));

        panelAsistente.setBackground(new java.awt.Color(0, 0, 102));
        panelAsistente.setForeground(new java.awt.Color(255, 255, 255));

        lblAsistente.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        lblAsistente.setForeground(new java.awt.Color(255, 255, 255));
        lblAsistente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/asistente.png"))); // NOI18N
        lblAsistente.setText("Asistente");

        javax.swing.GroupLayout panelAsistenteLayout = new javax.swing.GroupLayout(panelAsistente);
        panelAsistente.setLayout(panelAsistenteLayout);
        panelAsistenteLayout.setHorizontalGroup(
            panelAsistenteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAsistenteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblAsistente, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                .addGap(61, 61, 61))
        );
        panelAsistenteLayout.setVerticalGroup(
            panelAsistenteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAsistenteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblAsistente)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Menu.add(panelAsistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 200, -1));

        panelLogo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelLogo.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 190, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/usuario_5x5cm.png"))); // NOI18N
        jLabel9.setText("jLabel9");
        panelLogo.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 200, 130));

        Cabecera.setBackground(new java.awt.Color(0, 255, 204));
        Cabecera.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Cambria", 2, 48)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Asistente HelpDesk");
        Cabecera.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 430, 60));

        btnsalir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnsalir.setText("Salir");
        Cabecera.add(btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 80, 80, 20));

        jTabbedPane3.setFont(new java.awt.Font("Calibri", 1, 13)); // NOI18N

        jPanel21.setBackground(new java.awt.Color(0, 153, 153));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel22.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Incidencias", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Titulo:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Descripcion:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Categoria:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Prioridad:");

        txtInciTit.setToolTipText("");

        txtInciDes.addActionListener(this::txtInciDesActionPerformed);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Estado:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Usuario:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Tecnico:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("ID:");

        txtInciEst.addActionListener(this::txtInciEstActionPerformed);

        txtInciUsu.addActionListener(this::txtInciUsuActionPerformed);

        txtInciId.setEditable(false);

        btnInciReg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnInciReg.setText("Registrar");

        btnInciMod.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnInciMod.setText("Modificar");

        btnInciElim.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnInciElim.setText("Eliminar");

        btnInciLim.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnInciLim.setText("Limpiar");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtInciPrio, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtInciTit, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtInciDes, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(comboxInciCate, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(35, 35, 35)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(39, 39, 39)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtInciEst, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtInciUsu, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtInciTec, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtInciId, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnInciMod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnInciReg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnInciElim, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnInciLim, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtInciTit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtInciEst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInciReg))
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtInciDes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtInciUsu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInciMod))
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8)
                    .addComponent(txtInciTec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInciElim)
                    .addComponent(comboxInciCate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtInciPrio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtInciId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInciLim))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        jPanel21.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 600, 230));

        TableIncidencia.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TableIncidencia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Titulo", "Categoria", "Prioridad", "Estado", "Usuario", "Tecnico"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(TableIncidencia);
        if (TableIncidencia.getColumnModel().getColumnCount() > 0) {
            TableIncidencia.getColumnModel().getColumn(4).setHeaderValue("Precio ");
            TableIncidencia.getColumnModel().getColumn(5).setHeaderValue("Cantidad");
        }

        jPanel21.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 610, 160));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel21.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 466, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane3.addTab("Incidencias", jPanel2);

        jPanel3.setBackground(new java.awt.Color(0, 153, 204));

        jPanel18.setBackground(new java.awt.Color(0, 153, 153));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel30.setText("Codigo:");

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel31.setText("Nombre:");

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel32.setText("Precio:");

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel33.setText("Descripcion:");

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel34.setText("Categoria:");

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel35.setText("Id:");

        txtUsuCod2.setEditable(false);

        txtUsuId2.setEditable(false);
        txtUsuId2.setEnabled(false);

        btnUsuReg2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUsuReg2.setText("Registrar");

        btnUsuMod2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUsuMod2.setText("Modificar");

        btnUsuElim2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUsuElim2.setText("Eliminar");

        btnUsuCanc2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUsuCanc2.setText("Cancelar");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                        .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtUsuPre2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtUsuNom2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtUsuCod2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtUsuDes2)
                    .addComponent(txtUsuId2)
                    .addComponent(comboxUsuCat2, 0, 96, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnUsuMod2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUsuCanc2)
                    .addComponent(btnUsuReg2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUsuElim2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(92, 92, 92))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addGap(44, 44, 44)
                        .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel19Layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel35)
                                    .addComponent(txtUsuPre2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32)
                                    .addComponent(txtUsuId2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnUsuCanc2)))
                            .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel34)
                                .addComponent(comboxUsuCat2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(txtUsuCod2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUsuDes2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnUsuReg2))
                        .addGap(18, 18, 18)
                        .addComponent(btnUsuMod2)
                        .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel19Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel31)
                                    .addComponent(txtUsuNom2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel19Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(btnUsuElim2)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel18.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 600, 230));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel36.setText("Buscar:");
        jPanel18.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        jTextField19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPanel18.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, 130, -1));

        TableUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Codigo", "Nombre", "Descripcion", "Precio ", "Cantidad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(TableUsuario);
        if (TableUsuario.getColumnModel().getColumnCount() > 0) {
            TableUsuario.getColumnModel().getColumn(4).setHeaderValue("Precio ");
            TableUsuario.getColumnModel().getColumn(5).setHeaderValue("Cantidad");
        }

        jPanel18.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 610, 130));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel18.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 676, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Usuarios", jPanel3);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setToolTipText("");

        jPanel24.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tecnicos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Nombre:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Apellido:");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("CI:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Telefono:");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Correo:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Especialidad:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Estado:");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("ID Tecnico:");

        btnTecRegistrar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnTecRegistrar.setText("Registrar");

        btnTecModif.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnTecModif.setText("Modificar");

        btnTecElimi.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnTecElimi.setText("Eliminar");
        btnTecElimi.addActionListener(this::btnTecElimiActionPerformed);

        btnTecLim.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnTecLim.setText("Limpiar");
        btnTecLim.addActionListener(this::btnTecLimActionPerformed);

        txtTecNom.setName(""); // NOI18N

        txtTecTelef.addActionListener(this::txtTecTelefActionPerformed);

        txtTecID.addActionListener(this::txtTecIDActionPerformed);

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txxTecApell, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTecCI, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTecTelef, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTecNom, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(55, 55, 55)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(txtTecID, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addComponent(btnTecLim, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(txtTecCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnTecRegistrar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(comboxTecEstado, 0, 100, Short.MAX_VALUE)
                            .addComponent(comboxTecEspec, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnTecModif, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnTecElimi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(19, 19, 19))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel15)
                    .addComponent(btnTecRegistrar)
                    .addComponent(txtTecNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTecCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel16)
                    .addComponent(btnTecModif)
                    .addComponent(txxTecApell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboxTecEspec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel17)
                    .addComponent(btnTecElimi)
                    .addComponent(txtTecCI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboxTecEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTecTelef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel18)
                    .addComponent(txtTecID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTecLim))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        TableUsuario1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Apellido", "CI", "Telefono", "Especialidad", "Estado", "Correo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(TableUsuario1);
        if (TableUsuario1.getColumnModel().getColumnCount() > 0) {
            TableUsuario1.getColumnModel().getColumn(4).setHeaderValue("Precio ");
            TableUsuario1.getColumnModel().getColumn(5).setHeaderValue("Cantidad");
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(91, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Tecnicos", jPanel4);

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));

        jPanel25.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Categorias", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("ID Categoria:");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Nombre:");

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Estado:");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setText("Descripcion:");

        btnCateRegis.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCateRegis.setText("Registrar");

        btnCatecModif.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCatecModif.setText("Modificar");

        btnCatecLimp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCatecLimp.setText("Limpiar");

        btnCatecElimi.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCatecElimi.setText("Eliminar");
        btnCatecElimi.addActionListener(this::btnCatecElimiActionPerformed);

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addComponent(btnCateRegis)
                .addGap(206, 206, 206)
                .addComponent(btnCatecLimp)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(38, 38, 38)))
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(txtCateID, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtCateNom)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(comboxCateEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtCateDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(btnCatecModif)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnCatecElimi)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21)
                    .addComponent(txtCateID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCateNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboxCateEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(txtCateDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCateRegis)
                    .addComponent(btnCatecModif)
                    .addComponent(btnCatecLimp)
                    .addComponent(btnCatecElimi))
                .addGap(34, 34, 34))
        );

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel37.setText("Buscar:");

        txtCateBuscar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        tableCategorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Descripcion", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tableCategorias);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel37)
                        .addGap(25, 25, 25)
                        .addComponent(txtCateBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel37)
                    .addComponent(txtCateBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(87, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Categorias", jPanel5);

        jPanel6.setBackground(new java.awt.Color(0, 153, 153));

        jPanel10.setBackground(new java.awt.Color(0, 153, 153));

        jPanel29.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Especialidades", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("ID Categoria:");

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel38.setText("Nombre:");

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel39.setText("Estado:");

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel40.setText("Descripcion:");

        btnEspecRegis.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnEspecRegis.setText("Registrar");

        btnEspecMod.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnEspecMod.setText("Modificar");

        btnEspecLimp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnEspecLimp.setText("Limpiar");

        btnEspecElimi.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnEspecElimi.setText("Eliminar");
        btnEspecElimi.addActionListener(this::btnEspecElimiActionPerformed);

        jLabel42.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel42.setText("Nivel:");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addComponent(btnEspecRegis)
                        .addGap(206, 206, 206)
                        .addComponent(btnEspecLimp)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel29Layout.createSequentialGroup()
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                .addGroup(jPanel29Layout.createSequentialGroup()
                                    .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGap(38, 38, 38)))
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(69, 69, 69)))
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addComponent(txtEspecID, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtEspecNom, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboxEspecEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel29Layout.createSequentialGroup()
                                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtEspecDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel29Layout.createSequentialGroup()
                                            .addGap(20, 20, 20)
                                            .addComponent(btnEspecMod)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnEspecElimi)))
                                    .addComponent(comboxEspecNivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel38)
                    .addComponent(jLabel39)
                    .addComponent(txtEspecID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEspecNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboxEspecEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(comboxEspecNivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEspecDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40))
                .addGap(18, 18, 18)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEspecRegis)
                    .addComponent(btnEspecMod)
                    .addComponent(btnEspecLimp)
                    .addComponent(btnEspecElimi))
                .addGap(34, 34, 34))
        );

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel41.setText("Buscar:");

        txtEspecBuscar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtEspecBuscar.addActionListener(this::txtEspecBuscarActionPerformed);

        tableEspecialidades.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Descripcion", "Estado", "Nivel"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(tableEspecialidades);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(35, 35, 35)
                        .addComponent(txtEspecBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(txtEspecBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 682, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 466, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                    .addContainerGap(9, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(53, Short.MAX_VALUE)))
        );

        jTabbedPane3.addTab("Especialidades", jPanel6);

        jPanel7.setBackground(new java.awt.Color(0, 153, 153));
        jPanel7.setForeground(new java.awt.Color(255, 255, 255));

        jPanel27.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Reportes", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel43.setText("Fecha desde:");

        jLabel44.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel44.setText("Fecha hasta:");

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel45.setText("Categoria:");

        txtReporFecha.addActionListener(this::txtReporFechaActionPerformed);

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel46.setText("Prioridad:");

        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel47.setText("Estado:");

        jLabel48.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel48.setText("Tecnico:");

        btnReportGene.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnReportGene.setText("Generar");

        btnReporLimp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnReporLimp.setText("Limpiar");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(txtReportPrio, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addGap(4, 4, 4)
                        .addComponent(txtReporFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel44)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtReporEsta, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReporFechaH, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtReportTec, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addGap(35, 35, 35)
                        .addComponent(txtReportCate, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(28, 28, 28))
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(102, 102, 102)
                .addComponent(btnReportGene)
                .addGap(130, 130, 130)
                .addComponent(btnReporLimp)
                .addGap(56, 56, 56))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(jLabel44)
                    .addComponent(jLabel45)
                    .addComponent(txtReporFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReporFechaH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReportCate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(jLabel47)
                    .addComponent(jLabel48)
                    .addComponent(txtReportPrio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReporEsta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReportTec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReportGene)
                    .addComponent(btnReporLimp))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        tableReportes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Titulo", "Categoria", "Prioridad", "Estado", "Tecnico"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane9.setViewportView(tableReportes);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(117, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Reportes", jPanel7);

        jPanel9.setBackground(new java.awt.Color(0, 153, 153));
        jPanel9.setForeground(new java.awt.Color(255, 255, 255));

        jPanel28.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Asistente IA", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 590, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(218, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Asistente IA", jPanel9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(244, Short.MAX_VALUE)
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(220, 220, 220)
                            .addComponent(Cabecera, javax.swing.GroupLayout.PREFERRED_SIZE, 690, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 501, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 14, Short.MAX_VALUE)
                    .addComponent(Cabecera, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 14, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtInciDesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInciDesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInciDesActionPerformed

    private void txtInciEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInciEstActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInciEstActionPerformed

    private void txtInciUsuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInciUsuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInciUsuActionPerformed

    private void txtTecTelefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTecTelefActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTecTelefActionPerformed

    private void txtTecIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTecIDActionPerformed
        // Al presionar Enter en el campo ID, busca ese tecnico y llena el formulario (para Modificar)
        try {
            int id = Integer.parseInt(txtTecID.getText().trim());
            tecnicoController.cargarTecnicoEnFormulario(id, txtTecNom, txxTecApell, txtTecCI, txtTecTelef,
                    txtTecCorreo, comboxTecEspec, comboxTecEstado, txtTecID);
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Escribe un Id de tecnico valido (numero).");
        }
    }//GEN-LAST:event_txtTecIDActionPerformed

    private void btnTecElimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTecElimiActionPerformed
        try {
            int id = Integer.parseInt(txtTecID.getText().trim());
            boolean ok = tecnicoController.eliminarTecnico(id);
            if (ok) {
                cargarTablaTecnicos();

                tecnicoController.cancelar(txtTecID, txtTecNom, txxTecApell, txtTecCI, txtTecTelef, txtTecCorreo);
            }
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Escribe o selecciona el Id del tecnico a eliminar.");
        }
    }//GEN-LAST:event_btnTecElimiActionPerformed

    private void btnTecLimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTecLimActionPerformed
        tecnicoController.cancelar(txtTecID, txtTecNom, txxTecApell, txtTecCI, txtTecTelef, txtTecCorreo);
        if (comboxTecEspec.getItemCount() > 0) {
            comboxTecEspec.setSelectedIndex(0);
        }
        if (comboxTecEstado.getItemCount() > 0) {
            comboxTecEstado.setSelectedIndex(0);
        }
    }//GEN-LAST:event_btnTecLimActionPerformed

    private void btnTecRegistrarActionPerformed(java.awt.event.ActionEvent evt) {
        boolean ok = tecnicoController.registrarTecnico(
                txtTecNom.getText().trim(),
                txxTecApell.getText().trim(),
                txtTecCI.getText().trim(),
                txtTecTelef.getText().trim(),
                txtTecCorreo.getText().trim(),
                (String) comboxTecEspec.getSelectedItem(),
                (String) comboxTecEstado.getSelectedItem());
        if (ok) {
            cargarTablaTecnicos();

            tecnicoController.cancelar(txtTecID, txtTecNom, txxTecApell, txtTecCI, txtTecTelef, txtTecCorreo);
        }
    }

    private void btnTecModifActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int id = Integer.parseInt(txtTecID.getText().trim());
            boolean ok = tecnicoController.modificarTecnico(
                    id,
                    txtTecNom.getText().trim(),
                    txxTecApell.getText().trim(),
                    txtTecCI.getText().trim(),
                    txtTecTelef.getText().trim(),
                    txtTecCorreo.getText().trim(),
                    (String) comboxTecEspec.getSelectedItem(),
                    (String) comboxTecEstado.getSelectedItem());
            if (ok) {
                cargarTablaTecnicos();

                tecnicoController.cancelar(txtTecID, txtTecNom, txxTecApell, txtTecCI, txtTecTelef, txtTecCorreo);
            }
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Escribe o selecciona el Id del tecnico a modificar.");
        }
    }

    private void btnCatecElimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCatecElimiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCatecElimiActionPerformed

    private void btnEspecElimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEspecElimiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEspecElimiActionPerformed

    private void txtEspecBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEspecBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEspecBuscarActionPerformed

    private void txtReporFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtReporFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtReporFechaActionPerformed

    private void lblReportesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReportesMouseClicked
                jTabbedPane3.setSelectedIndex(5);
    }//GEN-LAST:event_lblReportesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new InterfazPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Cabecera;
    public javax.swing.JPanel Menu;
    public javax.swing.JTable TableIncidencia;
    public javax.swing.JTable TableUsuario;
    public javax.swing.JTable TableUsuario1;
    public javax.swing.JButton btnCateRegis;
    public javax.swing.JButton btnCatecElimi;
    public javax.swing.JButton btnCatecLimp;
    public javax.swing.JButton btnCatecModif;
    public javax.swing.JButton btnEspecElimi;
    public javax.swing.JButton btnEspecLimp;
    public javax.swing.JButton btnEspecMod;
    public javax.swing.JButton btnEspecRegis;
    public javax.swing.JButton btnInciElim;
    public javax.swing.JButton btnInciLim;
    public javax.swing.JButton btnInciMod;
    public javax.swing.JButton btnInciReg;
    private javax.swing.JButton btnReporLimp;
    private javax.swing.JButton btnReportGene;
    public javax.swing.JButton btnTecElimi;
    public javax.swing.JButton btnTecLim;
    public javax.swing.JButton btnTecModif;
    public javax.swing.JButton btnTecRegistrar;
    public javax.swing.JButton btnUsuCanc2;
    public javax.swing.JButton btnUsuElim2;
    public javax.swing.JButton btnUsuMod2;
    public javax.swing.JButton btnUsuReg2;
    private javax.swing.JButton btnsalir;
    public javax.swing.JComboBox<String> comboxCateEstado;
    public javax.swing.JComboBox<String> comboxEspecEstado;
    public javax.swing.JComboBox<String> comboxEspecNivel;
    public javax.swing.JComboBox<String> comboxInciCate;
    public javax.swing.JComboBox<String> comboxTecEspec;
    public javax.swing.JComboBox<String> comboxTecEstado;
    public javax.swing.JComboBox<Object> comboxUsuCat2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    public javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    public javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    public javax.swing.JPanel jPanel7;
    public javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane3;
    public javax.swing.JTextField jTextField19;
    public javax.swing.JLabel lblAsistente;
    public javax.swing.JLabel lblCategorias;
    public javax.swing.JLabel lblEspecialidades;
    public javax.swing.JLabel lblReportes;
    public javax.swing.JLabel lblTecnicos;
    private javax.swing.JLabel lblTitulo;
    public javax.swing.JLabel lblUsuario;
    public javax.swing.JLabel lblincidencias;
    public javax.swing.JPanel panelAsistente;
    public javax.swing.JPanel panelCategorias;
    public javax.swing.JPanel panelEspecialidades;
    private javax.swing.JPanel panelLogo;
    public javax.swing.JPanel panelReportes;
    public javax.swing.JPanel panelTecnicos;
    public javax.swing.JPanel panelUsuarios;
    public javax.swing.JPanel panelincidencia;
    public javax.swing.JTable tableCategorias;
    public javax.swing.JTable tableEspecialidades;
    public javax.swing.JTable tableReportes;
    public javax.swing.JTextField txtCateBuscar;
    public javax.swing.JTextField txtCateDescrip;
    private javax.swing.JTextField txtCateID;
    public javax.swing.JTextField txtCateNom;
    public javax.swing.JTextField txtEspecBuscar;
    public javax.swing.JTextField txtEspecDescrip;
    private javax.swing.JTextField txtEspecID;
    public javax.swing.JTextField txtEspecNom;
    public javax.swing.JTextField txtInciDes;
    public javax.swing.JTextField txtInciEst;
    public javax.swing.JTextField txtInciId;
    public javax.swing.JTextField txtInciPrio;
    public javax.swing.JTextField txtInciTec;
    public javax.swing.JTextField txtInciTit;
    public javax.swing.JTextField txtInciUsu;
    private javax.swing.JTextField txtReporEsta;
    private javax.swing.JTextField txtReporFecha;
    private javax.swing.JTextField txtReporFechaH;
    private javax.swing.JTextField txtReportCate;
    private javax.swing.JTextField txtReportPrio;
    private javax.swing.JTextField txtReportTec;
    public javax.swing.JTextField txtTecCI;
    public javax.swing.JTextField txtTecCorreo;
    private javax.swing.JTextField txtTecID;
    public javax.swing.JTextField txtTecNom;
    public javax.swing.JTextField txtTecTelef;
    public javax.swing.JTextField txtUsuCod2;
    public javax.swing.JTextField txtUsuDes2;
    public javax.swing.JTextField txtUsuId2;
    public javax.swing.JTextField txtUsuNom2;
    public javax.swing.JTextField txtUsuPre2;
    public javax.swing.JTextField txxTecApell;
    // End of variables declaration//GEN-END:variables
}
