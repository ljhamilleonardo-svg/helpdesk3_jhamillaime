package reportes;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.ConexionesMySQL;

public class ReporteIncidencias {

    private static final String SELECT =
        "SELECT i.id, i.ticket, i.fecha, i.hora, i.titulo, i.prioridad, "
      + "CONCAT(u.nombre, ' ', u.apellido) AS usuario, "
      + "CONCAT(t.nombre, ' ', t.apellido) AS tecnico, "
      + "c.nombre AS categoria, e.nombre AS estado "
      + "FROM incidencia i "
      + "INNER JOIN usuario u ON i.usuario_id = u.id "
      + "LEFT JOIN tecnico t ON i.tecnico_id = t.id "
      + "INNER JOIN categoria c ON i.categoria_id = c.id_categoria "
      + "INNER JOIN estado e ON i.estado_id = e.id ";

    private String texto(String valor) {
        return (valor == null || valor.trim().isEmpty()) ? "Sin asignar" : valor;
    }

    // Una fecha vacia es valida (significa "sin filtro"). Formato: aaaa-mm-dd
    private boolean fechaValida(String f) {
        if (f.isEmpty()) return true;
        try {
            LocalDate.parse(f);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean filtrosValidos(String desde, String hasta) {
        if (!fechaValida(desde) || !fechaValida(hasta)) {
            JOptionPane.showMessageDialog(null,
                "Las fechas deben tener el formato aaaa-mm-dd.\nEjemplo: 2026-10-14");
            return false;
        }
        return true;
    }

    // Arma la consulta agregando solo los filtros que el usuario lleno
    private PreparedStatement preparar(Connection con, String desde, String hasta,
            String cat, String prio, String est, String tec) throws SQLException {
        StringBuilder sql = new StringBuilder(SELECT).append("WHERE 1=1 ");
        List<String> params = new ArrayList<>();
        if (!desde.isEmpty()) { sql.append("AND i.fecha >= ? "); params.add(desde); }
        if (!hasta.isEmpty()) { sql.append("AND i.fecha <= ? "); params.add(hasta); }
        if (!cat.isEmpty())   { sql.append("AND c.nombre LIKE ? "); params.add("%" + cat + "%"); }
        if (!prio.isEmpty())  { sql.append("AND i.prioridad LIKE ? "); params.add("%" + prio + "%"); }
        if (!est.isEmpty())   { sql.append("AND e.nombre LIKE ? "); params.add("%" + est + "%"); }
        if (!tec.isEmpty())   { sql.append("AND CONCAT(t.nombre, ' ', t.apellido) LIKE ? "); params.add("%" + tec + "%"); }
        sql.append("ORDER BY i.fecha DESC, i.hora DESC");

        PreparedStatement ps = con.prepareStatement(sql.toString());
        for (int k = 0; k < params.size(); k++) {
            ps.setString(k + 1, params.get(k));
        }
        return ps;
    }

    // ================= TABLA DE LA PANTALLA =================
    public DefaultTableModel consultar(String desde, String hasta, String cat,
            String prio, String est, String tec) {
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"Id", "Titulo", "Categoria", "Prioridad", "Estado", "Tecnico"}, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
        desde = desde.trim(); hasta = hasta.trim(); cat = cat.trim();
        prio = prio.trim(); est = est.trim(); tec = tec.trim();
        if (!filtrosValidos(desde, hasta)) return modelo;

        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return modelo;
            try (PreparedStatement ps = preparar(con, desde, hasta, cat, prio, est, tec);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    modelo.addRow(new Object[]{
                        rs.getInt("id"), rs.getString("titulo"), rs.getString("categoria"),
                        rs.getString("prioridad"), rs.getString("estado"), texto(rs.getString("tecnico"))
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar las incidencias:\n" + e.getMessage());
        }
        return modelo;
    }

    // ================= PDF =================
    public void generarPdf(String desde, String hasta, String cat,
            String prio, String est, String tec) {
        desde = desde.trim(); hasta = hasta.trim(); cat = cat.trim();
        prio = prio.trim(); est = est.trim(); tec = tec.trim();
        if (!filtrosValidos(desde, hasta)) return;

        File carpeta = new File(System.getProperty("user.home"), "Documents");
        if (!carpeta.exists()) carpeta = new File(System.getProperty("user.home"));
        String nombre = "ReporteIncidencias_"
                + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".pdf";
        File archivo = new File(carpeta, nombre);

        Document documento = new Document(PageSize.A4.rotate(), 30, 30, 30, 30);

        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return;
            try (PreparedStatement ps = preparar(con, desde, hasta, cat, prio, est, tec);
                 ResultSet rs = ps.executeQuery()) {

                PdfWriter.getInstance(documento, new FileOutputStream(archivo));
                documento.open();

                Font fTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.DARK_GRAY);
                Paragraph titulo = new Paragraph("REPORTE DE INCIDENCIAS", fTitulo);
                titulo.setAlignment(Element.ALIGN_CENTER);
                documento.add(titulo);

                Font fSub = FontFactory.getFont(FontFactory.HELVETICA, 10, BaseColor.GRAY);
                String generado = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
                Paragraph pFecha = new Paragraph("Generado el: " + generado, fSub);
                pFecha.setAlignment(Element.ALIGN_CENTER);
                documento.add(pFecha);

                // Resumen de los filtros usados
                StringBuilder f = new StringBuilder();
                if (!desde.isEmpty()) f.append("Desde: ").append(desde).append("   ");
                if (!hasta.isEmpty()) f.append("Hasta: ").append(hasta).append("   ");
                if (!cat.isEmpty())   f.append("Categoria: ").append(cat).append("   ");
                if (!prio.isEmpty())  f.append("Prioridad: ").append(prio).append("   ");
                if (!est.isEmpty())   f.append("Estado: ").append(est).append("   ");
                if (!tec.isEmpty())   f.append("Tecnico: ").append(tec).append("   ");
                Paragraph pFiltros = new Paragraph(
                        f.length() == 0 ? "Filtros: ninguno (todas las incidencias)" : "Filtros: " + f, fSub);
                pFiltros.setAlignment(Element.ALIGN_CENTER);
                pFiltros.setSpacingAfter(15);
                documento.add(pFiltros);

                PdfPTable tabla = new PdfPTable(9);
                tabla.setWidthPercentage(100);
                tabla.setWidths(new float[]{1.6f, 1.8f, 1.3f, 4f, 1.5f, 2.4f, 2.4f, 2.6f, 1.7f});
                tabla.setHeaderRows(1);

                Font fCab = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, BaseColor.WHITE);
                String[] cabeceras = {"Ticket", "Fecha", "Hora", "Título", "Prioridad",
                                      "Usuario", "Técnico", "Categoría", "Estado"};
                for (String c : cabeceras) {
                    PdfPCell celda = new PdfPCell(new Phrase(c, fCab));
                    celda.setBackgroundColor(new BaseColor(0, 0, 128));
                    celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                    celda.setPadding(6);
                    tabla.addCell(celda);
                }

                Font fDato = FontFactory.getFont(FontFactory.HELVETICA, 9);
                int total = 0;
                while (rs.next()) {
                    tabla.addCell(new Phrase(texto(rs.getString("ticket")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("fecha")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("hora")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("titulo")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("prioridad")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("usuario")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("tecnico")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("categoria")), fDato));
                    tabla.addCell(new Phrase(texto(rs.getString("estado")), fDato));
                    total++;
                }
                documento.add(tabla);

                Paragraph pTotal = new Paragraph("Total de incidencias: " + total,
                        FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11));
                pTotal.setSpacingBefore(15);
                documento.add(pTotal);

                documento.close();
                JOptionPane.showMessageDialog(null, "PDF generado en:\n" + archivo.getAbsolutePath());
                Desktop.getDesktop().open(archivo);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al generar el PDF:\n" + e.getMessage());
        }
    }
}