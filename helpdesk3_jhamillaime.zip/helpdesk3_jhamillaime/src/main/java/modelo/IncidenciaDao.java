package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/** Persistencia de incidencias del helpdesk. Usuario y técnico se indican por ID. */
public class IncidenciaDao {
    public DefaultTableModel listar() {
        DefaultTableModel m = new DefaultTableModel(
                new Object[]{"Id", "Ticket", "Titulo", "Categoria", "Prioridad", "Estado", "Usuario", "Tecnico"}, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
        String sql = "SELECT i.id, i.ticket, i.titulo, c.nombre, i.prioridad, e.nombre, i.usuario_id, i.tecnico_id "
                + "FROM incidencia i JOIN categoria c ON c.id_categoria=i.categoria_id "
                + "JOIN estado e ON e.id=i.estado_id ORDER BY i.id DESC";
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return m;
            try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) m.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7),
                    rs.getObject(8) == null ? "" : rs.getInt(8)});
            }
        } catch (SQLException ex) { error("listar incidencias", ex); }
        return m;
    }

    public boolean guardar(Integer id, String titulo, String descripcion, String categoria,
            String prioridad, String estado, int usuarioId, Integer tecnicoId) {
        String sql = id == null
                ? "INSERT INTO incidencia (ticket, fecha, hora, titulo, descripcion, prioridad, usuario_id, tecnico_id, categoria_id, estado_id) "
                  + "VALUES (?, CURDATE(), CURTIME(), ?, ?, ?, ?, ?, (SELECT id_categoria FROM categoria WHERE nombre=?), (SELECT id FROM estado WHERE nombre=?))"
                : "UPDATE incidencia SET titulo=?, descripcion=?, prioridad=?, usuario_id=?, tecnico_id=?, "
                  + "categoria_id=(SELECT id_categoria FROM categoria WHERE nombre=?), estado_id=(SELECT id FROM estado WHERE nombre=?) WHERE id=?";
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return false;
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                int n = 1;
                if (id == null) ps.setString(n++, "HD-" + System.currentTimeMillis());
                ps.setString(n++, titulo); ps.setString(n++, descripcion);
                if (id == null) ps.setString(n++, prioridad);
                else ps.setString(n++, prioridad);
                ps.setInt(n++, usuarioId);
                if (tecnicoId == null) ps.setNull(n++, java.sql.Types.INTEGER); else ps.setInt(n++, tecnicoId);
                ps.setString(n++, categoria); ps.setString(n++, estado);
                if (id != null) ps.setInt(n, id);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) { error("guardar incidencia", ex); return false; }
    }

    public boolean eliminar(int id) {
        try (Connection con = new ConexionesMySQL().getConexion();
             PreparedStatement ps = con == null ? null : con.prepareStatement("DELETE FROM incidencia WHERE id=?")) {
            if (ps == null) return false;
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (SQLException ex) { error("eliminar incidencia", ex); return false; }
    }

    private void error(String op, SQLException ex) {
        JOptionPane.showMessageDialog(null, "No se pudo " + op + ": " + ex.getMessage(), "Base de datos", JOptionPane.ERROR_MESSAGE);
    }
}