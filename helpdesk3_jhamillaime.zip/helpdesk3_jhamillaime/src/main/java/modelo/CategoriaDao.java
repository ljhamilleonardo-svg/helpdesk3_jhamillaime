package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/** Carga las categorías activas para los formularios de incidencias. */
public class CategoriaDao {
    private static DefaultTableModel modeloTabla() {
        return new DefaultTableModel(new Object[]{"Id", "Nombre", "Descripcion", "Estado"}, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
    }

    public DefaultTableModel listar() { return buscar(""); }

    public DefaultTableModel buscar(String texto) {
        DefaultTableModel modelo = modeloTabla();
        String sql = "SELECT id_categoria, nombre, descripcion, estado FROM categoria "
                + "WHERE nombre LIKE ? OR descripcion LIKE ? ORDER BY nombre";
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return modelo;
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, "%" + texto + "%");
                ps.setString(2, "%" + texto + "%");
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) modelo.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)});
                }
            }
        } catch (SQLException ex) { error("listar categorías", ex); }
        return modelo;
    }

    public boolean guardar(Integer id, String nombre, String descripcion, String estado) {
        String sql = id == null
                ? "INSERT INTO categoria (nombre, descripcion, estado) VALUES (?, ?, ?)"
                : "UPDATE categoria SET nombre=?, descripcion=?, estado=? WHERE id_categoria=?";
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return false;
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, nombre); ps.setString(2, descripcion); ps.setString(3, estado);
                if (id != null) ps.setInt(4, id);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) { error("guardar categoría", ex); return false; }
    }

    public boolean eliminar(int id) {
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) return false;
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM categoria WHERE id_categoria=?")) {
                ps.setInt(1, id); return ps.executeUpdate() > 0;
            }
        } catch (SQLException ex) { error("eliminar categoría (puede estar en uso)", ex); return false; }
    }

    private void error(String operacion, SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al " + operacion + ": " + ex.getMessage(),
                "Base de datos", JOptionPane.ERROR_MESSAGE);
    }

    public Map<Integer, String> listarActivas() {
        Map<Integer, String> categorias = new LinkedHashMap<>();
        String sql = "SELECT id_categoria, nombre FROM categoria "
                + "WHERE estado = 'Activo' ORDER BY nombre";
        try (Connection con = new ConexionesMySQL().getConexion()) {
            if (con == null) {
                return categorias;
            }
            try (PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    categorias.put(rs.getInt("id_categoria"), rs.getString("nombre"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "No se pudieron cargar las categorías. Verifica que exista la tabla categoria "
                    + "y que tenga id_categoria, nombre y estado.\n" + ex.getMessage(),
                    "Error de categorías", JOptionPane.ERROR_MESSAGE);
        }
        return categorias;
    }
}
