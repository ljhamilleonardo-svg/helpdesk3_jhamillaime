package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EspecialidadDao {
    private DefaultTableModel modelo() {
        return new DefaultTableModel(new Object[]{"Id", "Nombre", "Descripcion", "Estado", "Nivel"}, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
    }
    public DefaultTableModel listar(String filtro) {
        DefaultTableModel m=modelo();
        String sql="SELECT id,nombre,descripcion,estado,nivel FROM especialidad WHERE nombre LIKE ? OR descripcion LIKE ? ORDER BY nombre";
        try(Connection c=new ConexionesMySQL().getConexion()) {
            if(c==null)return m;
            try(PreparedStatement p=c.prepareStatement(sql)) {
                p.setString(1,"%"+filtro+"%"); p.setString(2,"%"+filtro+"%");
                try(ResultSet r=p.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5)});}
            }
        } catch(SQLException e){error(e);} return m;
    }
    public boolean guardar(Integer id,String nombre,String descripcion,String estado,String nivel) {
        String sql=id==null?"INSERT INTO especialidad(nombre,descripcion,estado,nivel) VALUES(?,?,?,?)":"UPDATE especialidad SET nombre=?,descripcion=?,estado=?,nivel=? WHERE id=?";
        try(Connection c=new ConexionesMySQL().getConexion()) {
            if(c==null)return false;
            try(PreparedStatement p=c.prepareStatement(sql)) {
                p.setString(1,nombre);p.setString(2,descripcion);p.setString(3,estado);p.setString(4,nivel);
                if(id!=null)p.setInt(5,id);return p.executeUpdate()>0;
            }
        }catch(SQLException e){error(e);return false;}
    }
    public boolean eliminar(int id) {
        try(Connection c=new ConexionesMySQL().getConexion()) {
            if(c==null)return false;
            try(PreparedStatement p=c.prepareStatement("DELETE FROM especialidad WHERE id=?")){p.setInt(1,id);return p.executeUpdate()>0;}
        }catch(SQLException e){error(e);return false;}
    }
    private void error(SQLException e){JOptionPane.showMessageDialog(null,"Error de especialidades: "+e.getMessage(),"Base de datos",JOptionPane.ERROR_MESSAGE);}
}