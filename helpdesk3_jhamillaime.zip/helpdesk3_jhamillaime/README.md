# HelpDesk 3 — guía para ejecutar y entregar

## Requisitos

- JDK 25 (el proyecto compila con `maven.compiler.release=25`).
- MySQL Server local en `localhost:3306`.
- NetBeans con Maven, o Maven instalado.

## Preparar la base de datos

1. Abre MySQL Workbench y ejecuta `database/helpdesk3.sql`.
2. La conexión predeterminada del proyecto es `root` sin contraseña. Si tu instalación usa otra cuenta/clave, cambia `src/main/java/modelo/ConexionesMySQL.java` antes de ejecutar.
3. Cuenta local de demostración: usuario `admin`, contraseña `admin123`. Cámbiala tras iniciar sesión.
4. Inicia `main.main` desde NetBeans. El proyecto Maven descarga JDBC, AbsoluteLayout e iText si no están disponibles localmente.

Para registrar tickets, escribe el ID numérico de usuario y, opcionalmente, el ID numérico del técnico. Las categorías y estados deben existir en la base.

## Asistente IA

El chat usa OpenAI Responses API. Define `OPENAI_API_KEY` en el entorno antes de abrir NetBeans y ejecútalo desde esa sesión. Puedes definir `OPENAI_MODEL` para seleccionar otro modelo habilitado en tu proyecto; por defecto usa `gpt-4o-mini`. Sin clave o conexión a Internet, el resto del sistema puede usarse y el asistente mostrará el error de configuración/conexión.

No incluyas la clave en el código ni la subas al repositorio. En una aplicación de escritorio distribuida, la clave del proveedor puede extraerse del equipo del usuario; para producción, mueve la llamada de IA a un servidor propio. Las credenciales API usan autenticación Bearer y deben manejarse como secreto según la [documentación oficial de OpenAI](https://developers.openai.com/api/reference/overview).

## Funciones conectadas

- Inicio de sesión y gestión de usuarios.
- Altas, cambios y bajas de técnicos, categorías y especialidades.
- Registro, edición, listado y eliminación de incidencias.
- Consulta de reportes y generación de PDF.
- Chat IA mediante Responses API.

## Consideraciones de entrega

La contraseña del ejemplo y la conexión MySQL local son solo para demostración. Para entregar, explica que MySQL debe estar activo y que el script SQL se ejecuta primero. El asistente necesita clave y acceso a Internet. El formulario de incidencias usa IDs para usuario y técnico; una mejora pendiente de usabilidad sería elegirlos desde listas con nombres.