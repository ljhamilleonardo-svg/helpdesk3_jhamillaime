CREATE DATABASE IF NOT EXISTS helpdesk3 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE helpdesk3;

CREATE TABLE IF NOT EXISTS usuario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  correo VARCHAR(160),
  telefono VARCHAR(40),
  usuario VARCHAR(80) NOT NULL UNIQUE,
  contrasena VARCHAR(255) NOT NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE,
  descripcion VARCHAR(500),
  estado VARCHAR(20) NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS especialidad (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE,
  descripcion VARCHAR(500),
  estado VARCHAR(20) NOT NULL DEFAULT 'Activo',
  nivel VARCHAR(40)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tecnico (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  ci VARCHAR(40) NOT NULL UNIQUE,
  telefono VARCHAR(40),
  correo VARCHAR(160),
  especialidad VARCHAR(100),
  estado VARCHAR(20) NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS estado (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS incidencia (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket VARCHAR(30) NOT NULL UNIQUE,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT,
  prioridad VARCHAR(30) NOT NULL,
  usuario_id INT NOT NULL,
  tecnico_id INT NULL,
  categoria_id INT NOT NULL,
  estado_id INT NOT NULL,
  CONSTRAINT fk_incidencia_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id),
  CONSTRAINT fk_incidencia_tecnico FOREIGN KEY (tecnico_id) REFERENCES tecnico(id) ON DELETE SET NULL,
  CONSTRAINT fk_incidencia_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id_categoria),
  CONSTRAINT fk_incidencia_estado FOREIGN KEY (estado_id) REFERENCES estado(id),
  INDEX idx_incidencia_fecha (fecha),
  INDEX idx_incidencia_estado (estado_id)
) ENGINE=InnoDB;

INSERT IGNORE INTO estado (nombre) VALUES ('Abierta'), ('En proceso'), ('Resuelta'), ('Cerrada');
INSERT IGNORE INTO categoria (nombre, descripcion, estado) VALUES
 ('Hardware', 'Problemas con equipos y periféricos', 'Activo'),
 ('Software', 'Problemas con aplicaciones y sistemas', 'Activo'),
 ('Redes', 'Problemas de conectividad', 'Activo');
INSERT IGNORE INTO especialidad (nombre, descripcion, estado, nivel) VALUES
 ('Hardware', 'Equipos y periféricos', 'Activo', 'Intermedio'),
 ('Software', 'Aplicaciones y sistemas', 'Activo', 'Intermedio'),
 ('Redes', 'Conectividad e infraestructura', 'Activo', 'Intermedio');

-- Cuenta inicial solo para demostración local; cambiar la contraseña tras ingresar.
INSERT IGNORE INTO usuario (nombre, apellido, correo, usuario, contrasena, estado) VALUES ('Administrador', 'HelpDesk', 'admin@localhost', 'admin', 'admin123', 'Activo');